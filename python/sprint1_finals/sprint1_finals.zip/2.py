# ID: 74396831

from typing import List, Tuple

def get_max_score(key_limit: int, keys: List[int]) -> int:
    keys_set = set(keys)
    count_keys = []
    
    for i in keys_set:
        count_keys.append(keys.count(i))
    
    return sum(k <= key_limit * 2 for k in count_keys)


def read_input() -> Tuple[int, List[int]]:
    key_limit = int(input())
    str1 = str(input())
    str2 = str(input())
    str3 = str(input())
    str4 = str(input())
    keys = []
    for i in str1 + str2 + str3 + str4:
        if i.isdigit():
            keys.append(int(i))
    return key_limit, keys

key_limit, keys = read_input()
print(get_max_score(key_limit, keys))