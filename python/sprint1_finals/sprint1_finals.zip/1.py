# ID: 74311656

from typing import List

def get_zero(street: List[int], ) -> List[int]:
    length = len(street)
    left_to_right = []
    for i in range(length):
        if street[i] == 0:
            left_to_right.append(0)
        elif i == 0:
            left_to_right.append(length)
        else:
            left_to_right.append(left_to_right[i-1]+1)
    
    street.reverse()    
    right_to_left = []
    for i in range(length):
        if street[i] == 0:
            right_to_left.append(0)
        elif i == 0:
            right_to_left.append(length)
        else:
            right_to_left.append(right_to_left[i-1]+1)
    right_to_left.reverse()   
    distance = []
    for i in range(length):
        distance.append(min(left_to_right[i], right_to_left[i]))
        
    return distance


def read_input() -> List[int]:
    n = int(input())
    street = list(map(int, input().strip().split()))
    return street

street = read_input()
print(" ".join(map(str, get_zero(street))))